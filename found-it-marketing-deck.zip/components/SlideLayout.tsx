import React from 'react';
import { motion, Variants } from 'framer-motion';

interface SlideLayoutProps {
  children: React.ReactNode;
  className?: string;
}

export const containerVariants: Variants = {
  hidden: { opacity: 0, scale: 0.95 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1,
      duration: 0.4
    }
  },
  exit: {
    opacity: 0,
    scale: 1.05,
    transition: {
      staggerChildren: 0.05,
      staggerDirection: -1,
      duration: 0.3
    }
  }
};

export const itemVariants: Variants = {
  hidden: { opacity: 0, y: 10 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: {
      type: "spring",
      stiffness: 100,
      damping: 15
    }
  },
  exit: { opacity: 0, y: -10 }
};

export const SlideLayout: React.FC<SlideLayoutProps> = ({ children, className = "" }) => {
  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      exit="exit"
      // Mobile-First "No Scroll" Strategy:
      // h-full ensures it takes available space between header and footer.
      // justify-center vertically centers content.
      // No overflow-y-auto.
      className={`w-full max-w-lg mx-auto px-6 h-full flex flex-col justify-center relative z-10 ${className}`}
    >
      {children}
    </motion.div>
  );
};